import numpy as np
import matplotlib.pyplot as plt
from lascar import * # source: https://github.com/Ledger-Donjon/lascar

plt.rcParams['figure.figsize'] = (20, 12)

AES_Sbox = np.array([
    0x63, 0x7C, 0x77, 0x7B, 0xF2, 0x6B, 0x6F, 0xC5, 0x30, 0x01, 0x67, 0x2B, 0xFE, 0xD7, 0xAB, 0x76,
    0xCA, 0x82, 0xC9, 0x7D, 0xFA, 0x59, 0x47, 0xF0, 0xAD, 0xD4, 0xA2, 0xAF, 0x9C, 0xA4, 0x72, 0xC0,
    0xB7, 0xFD, 0x93, 0x26, 0x36, 0x3F, 0xF7, 0xCC, 0x34, 0xA5, 0xE5, 0xF1, 0x71, 0xD8, 0x31, 0x15,
    0x04, 0xC7, 0x23, 0xC3, 0x18, 0x96, 0x05, 0x9A, 0x07, 0x12, 0x80, 0xE2, 0xEB, 0x27, 0xB2, 0x75,
    0x09, 0x83, 0x2C, 0x1A, 0x1B, 0x6E, 0x5A, 0xA0, 0x52, 0x3B, 0xD6, 0xB3, 0x29, 0xE3, 0x2F, 0x84,
    0x53, 0xD1, 0x00, 0xED, 0x20, 0xFC, 0xB1, 0x5B, 0x6A, 0xCB, 0xBE, 0x39, 0x4A, 0x4C, 0x58, 0xCF,
    0xD0, 0xEF, 0xAA, 0xFB, 0x43, 0x4D, 0x33, 0x85, 0x45, 0xF9, 0x02, 0x7F, 0x50, 0x3C, 0x9F, 0xA8,
    0x51, 0xA3, 0x40, 0x8F, 0x92, 0x9D, 0x38, 0xF5, 0xBC, 0xB6, 0xDA, 0x21, 0x10, 0xFF, 0xF3, 0xD2,
    0xCD, 0x0C, 0x13, 0xEC, 0x5F, 0x97, 0x44, 0x17, 0xC4, 0xA7, 0x7E, 0x3D, 0x64, 0x5D, 0x19, 0x73,
    0x60, 0x81, 0x4F, 0xDC, 0x22, 0x2A, 0x90, 0x88, 0x46, 0xEE, 0xB8, 0x14, 0xDE, 0x5E, 0x0B, 0xDB,
    0xE0, 0x32, 0x3A, 0x0A, 0x49, 0x06, 0x24, 0x5C, 0xC2, 0xD3, 0xAC, 0x62, 0x91, 0x95, 0xE4, 0x79,
    0xE7, 0xC8, 0x37, 0x6D, 0x8D, 0xD5, 0x4E, 0xA9, 0x6C, 0x56, 0xF4, 0xEA, 0x65, 0x7A, 0xAE, 0x08,
    0xBA, 0x78, 0x25, 0x2E, 0x1C, 0xA6, 0xB4, 0xC6, 0xE8, 0xDD, 0x74, 0x1F, 0x4B, 0xBD, 0x8B, 0x8A,
    0x70, 0x3E, 0xB5, 0x66, 0x48, 0x03, 0xF6, 0x0E, 0x61, 0x35, 0x57, 0xB9, 0x86, 0xC1, 0x1D, 0x9E,
    0xE1, 0xF8, 0x98, 0x11, 0x69, 0xD9, 0x8E, 0x94, 0x9B, 0x1E, 0x87, 0xE9, 0xCE, 0x55, 0x28, 0xDF,
    0x8C, 0xA1, 0x89, 0x0D, 0xBF, 0xE6, 0x42, 0x68, 0x41, 0x99, 0x2D, 0x0F, 0xB0, 0x54, 0xBB, 0x16
            ])

#### Generate traces for scenario 4
def generate_traces(nb_traces, samples, nb_poi=1, mu=0, sigma=1e-1, targeted_byte=0, training=True):
    """
    Function which generates a set of traces given the following parameters
    :param nb_traces: number of traces to generate
    :param samples: number of samples per generated trace
    :param nb_poi: number of points of interest per generated trace
    :param mu: mean of the univariate Gaussian distribution
    :param sigma: variance of the univariate Gaussian distribution
    :param targeted_byte: targeted byte
    :param training: boolean variable configured to set the secret key value (training = True -> random keys / training = False -> fixed key)
    :return:
    """

    # Initialization of the generated traces
    traces = np.empty(shape=(nb_traces,samples), dtype="float32")

    # Initialization of the data (ie. plaintext, secret_key, targeted_variable)
    if training == True:
        key = np.random.randint(0, 256, (nb_traces, 16), np.uint8)
    else:
        key = [0x4a, 0x58, 0x32, 0xae, 0x1f, 0x02, 0x96, 0xe1, 0xcc, 0x3d, 0xb4, 0x13, 0xaa, 0x8c, 0xf6, 0xa7]
    plaintext = np.random.randint(0, 256, (nb_traces, 16), np.uint8)
    targeted_variable = np.zeros((nb_traces,16), dtype='uint')

    # Construction of the simulated traces
    for i in range(traces.shape[0]):
        traces[i, :] = np.random.normal(mu, sigma, np.shape(traces)[1]) # Noise

        # Computation of the targeted variable (ie. Output Sbox)
        for j in range(16):
            if training == True:
                targeted_variable[i,j] = AES_Sbox[int(np.bitwise_xor(plaintext[i,j],key[i,j]))]
            else:
                targeted_variable[i,j] = AES_Sbox[int(np.bitwise_xor(plaintext[i,j],key[j]))]

        # Computation and insertion of the leakage model to the simulated traces (scenario 4)
        for l in range(nb_poi):
            traces[i, (int(samples/(nb_poi+1))*(l+1))] += (1*int(bin(targeted_variable[i,targeted_byte])[2:].zfill(8)[7-3]) + 1*int(bin(targeted_variable[i,targeted_byte])[2:].zfill(8)[7-6]))

    return plaintext, key, targeted_variable, traces

# This SNR computation is performed via the LASCAR tool (https://github.com/Ledger-Donjon/lascar) developed by Ledger (https://donjon.ledger.com/)
def plot_SNR(path_traces, path_targeted_value, nb_classes, nb_traces, targeted_byte=0):
    """
    Computation and plot of the SNR value
    :param path_traces: path to the simulated trace file
    :param path_targeted_value: path to the targeted variable file
    :param nb_classes: number of classes
    :param nb_traces: number of traces to compute the SNR value
    :param targeted_byte: targeted byte
    :return:
    """

    # Data container
    container = NpyContainer(path_traces, path_targeted_value)
    container.number_of_traces = nb_traces

    # Initialization of the engine
    snr_engine = SnrEngine('SNR: ',
                           lambda value: value[targeted_byte],
                           range(nb_classes))
    engines = [snr_engine]

    # Definition of the outputs provided by the session
    # Here, the SNR computation is saved and plotted
    output = [DictOutputMethod(*engines, filename='SNR_scenario4_'+str(noise)+'_nbsample'+str(nb_samples)+'.pickle'),
              MatPlotLibOutputMethod(*engines, single_plot=True, legend=True)]

    # Start the session
    session = Session(container, name='SNRs computing',
                      engines=engines, output_method=output)
    session.run(nb_traces)

    return np.load('SNR_scenario4_'+str(noise)+'_nbsample'+str(nb_samples)+'.pickle', allow_pickle=True)


# Settings
nb_traces = 20000 # Number of traces to generate
nb_samples = 1 # Number of samples per simulated trace
targeted_byte = 0
mu, sigma = 0, 0.3 # Parameters of the Gaussian distribution
nb_poi = 1
noise='high_noise'
bool_training = True

# Generation of the simulated traces
plaintext, key, targeted_value, traces = generate_traces(nb_traces, nb_samples, nb_poi=nb_poi, mu=mu, sigma=sigma, targeted_byte=targeted_byte, training=bool_training)

# Save the datasets
np.save('plaintext_scenario4_'+str(noise)+'_nbsample'+str(nb_samples)+'.npy', plaintext)
np.save('key_scenario4_'+str(noise)+'_nbsample'+str(nb_samples)+'.npy',key)
np.save('traces_scenario4_'+str(noise)+'_nbsample'+str(nb_samples)+'.npy',traces)
np.save('intermediate_value_scenario4_'+str(noise)+'_nbsample'+str(nb_samples)+'.npy', targeted_value)

# Computation of the SNR function
snr_value = plot_SNR('traces_scenario4_'+str(noise)+'_nbsample'+str(nb_samples)+'.npy', 'intermediate_value_scenario4_'+str(noise)+'_nbsample'+str(nb_samples)+'.npy', 256, nb_traces, targeted_byte=targeted_byte)

# Save the SNR plot
plt.plot(snr_value['SNR: '][nb_traces])
plt.xlabel('Time samples', fontsize=30)
plt.ylabel('SNR', fontsize=30)
plt.xticks(fontsize=30)
plt.yticks(fontsize=30)
plt.savefig('SNR_scenario4_'+str(noise)+'_nbsample'+str(nb_samples)+'.svg', format='svg',  dpi=12000)